import React, { useState, useCallback } from 'react'
import { TopBar }       from './components/TopBar'
import { SidebarLeft }  from './components/SidebarLeft'
import { LabWorkspace } from './components/LabWorkspace'
import { SidebarRight } from './components/SidebarRight'
import { StatusBar }    from './components/StatusBar'
import { useTitration } from './hooks/useTitration'
import { useHandGesture } from './hooks/useHandGesture'
import { loadSessions, saveSession } from './lib/chemLogic'

export default function App() {
  const [gestureActive, setGestureActive] = useState(false)
  const [sessions, setSessions]           = useState(() => loadSessions())
  const [activeTab, setActiveTab]         = useState('data')
  const [replayProgress, setReplayProgress] = useState(0)

  const {
    vol, pouring, started, showEndpoint, atEndpoint,
    colorInfo, suggestion, buretteRemaining, burettePercent, fillPercent,
    startPour, stopPour, reset, getSessionSnapshot, replaySession,
    experiment,
  } = useTitration()

  const handleGesture = useCallback((gesture) => {
    if (gesture === 'POUR') startPour()
    else stopPour()
  }, [startPour, stopPour])

  const { videoRef, canvasRef, status: gestureStatus, errorMsg } = useHandGesture({
    onGesture: handleGesture,
    enabled: gestureActive,
  })

  const handleSave = useCallback(() => {
    const snap = getSessionSnapshot()
    const next = saveSession(snap)
    setSessions(next)
    setActiveTab('history')
  }, [getSessionSnapshot])

  const handleReplay = useCallback((session) => {
    setActiveTab('data')
    let i = 0
    const total = session.events?.length || 1
    replaySession(session, () => setReplayProgress(100))
    const tick = setInterval(() => {
      i += 1
      setReplayProgress(Math.min(99, (i / total) * 100 * 30))
      if (i > total) { clearInterval(tick); setReplayProgress(0) }
    }, 30)
  }, [replaySession])

  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: '260px 1fr 280px',
      gridTemplateRows: '52px 1fr 44px',
      height: '100vh',
    }}>
      <TopBar
        expName={experiment.name}
        gestureActive={gestureActive}
        gestureStatus={gestureStatus}
        onToggleGesture={() => setGestureActive(g => !g)}
        onSave={handleSave}
      />
      <SidebarLeft experiment={experiment} />
      <LabWorkspace
        colorInfo={colorInfo}
        pouring={pouring}
        burettePercent={burettePercent}
        showEndpoint={showEndpoint}
        vol={vol}
        gestureActive={gestureActive}
        videoRef={videoRef}
        canvasRef={canvasRef}
        gestureStatus={gestureStatus}
        errorMsg={errorMsg}
      />
      <SidebarRight
        vol={vol}
        buretteRemaining={buretteRemaining}
        burettePercent={burettePercent}
        fillPercent={fillPercent}
        colorInfo={colorInfo}
        suggestion={suggestion}
        pouring={pouring}
        atEndpoint={atEndpoint}
        gestureActive={gestureActive}
        onStartPour={startPour}
        onStopPour={stopPour}
        onReset={reset}
        onSave={handleSave}
        replayProgress={replayProgress}
        sessions={sessions}
        onReplay={handleReplay}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />
      <StatusBar
        experiment={experiment}
        sessions={sessions.length}
        gestureActive={gestureActive}
        gestureStatus={gestureStatus}
        vol={vol}
      />
    </div>
  )
}
