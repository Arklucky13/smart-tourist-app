import React from 'react'

export function Beaker({ colorRgba, pouring }) {
  return (
    <div style={{ position: 'relative', marginTop: 'auto', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      {/* Flask rim */}
      <div
        style={{
          width: 130,
          height: 20,
          border: '2px solid rgba(200,230,255,0.2)',
          borderBottom: 'none',
          borderRadius: '8px 8px 0 0',
          background: 'rgba(200,230,255,0.02)',
          position: 'relative',
        }}
      >
        {/* Spout */}
        <div
          style={{
            position: 'absolute',
            right: -12,
            top: -4,
            width: 20,
            height: 12,
            background: 'rgba(200,230,255,0.04)',
            border: '2px solid rgba(200,230,255,0.2)',
            borderBottom: 'none',
            borderRadius: '4px 4px 0 0',
          }}
        />
      </div>

      {/* Flask body */}
      <div
        style={{
          width: 120,
          height: 140,
          position: 'relative',
          background: 'rgba(200,230,255,0.04)',
          border: '2px solid rgba(200,230,255,0.2)',
          borderTop: 'none',
          borderRadius: '0 0 12px 12px',
          overflow: 'hidden',
        }}
      >
        {/* Solution */}
        <div
          style={{
            position: 'absolute',
            bottom: 0,
            left: 0,
            right: 0,
            height: '68%',
            background: colorRgba,
            transition: 'background 0.6s ease',
          }}
        />

        {/* Bubbles when pouring */}
        {pouring && [1, 2, 3].map(i => (
          <div
            key={i}
            style={{
              position: 'absolute',
              bottom: 0,
              left: `${20 + i * 25}%`,
              width: 4,
              height: 4,
              borderRadius: '50%',
              background: 'rgba(255,255,255,0.2)',
              animation: `bubble-rise ${1.4 + i * 0.3}s ease-in infinite`,
              animationDelay: `${i * 0.4}s`,
            }}
          />
        ))}
      </div>

      <div style={{ marginTop: 8, fontSize: 10, color: 'var(--text-muted)', fontFamily: 'Space Mono', textAlign: 'center' }}>
        HCl (unknown)
      </div>
    </div>
  )
}
