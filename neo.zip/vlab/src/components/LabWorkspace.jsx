import React from 'react'
import { Burette } from './Burette'
import { Beaker } from './Beaker'
import { TeacherVideo } from './TeacherVideo'

export function LabWorkspace({
  colorInfo, pouring, burettePercent, showEndpoint, vol,
  gestureActive, videoRef, canvasRef, gestureStatus, errorMsg,
}) {
  return (
    <main className="relative overflow-hidden" style={{ background: 'var(--bg-deep)' }}>
      <div className="grid-bg absolute inset-0" />
      <div style={{
        position: 'absolute', bottom: 0, left: 0, right: 0, height: 80,
        background: 'linear-gradient(180deg,#1a2035 0%,#111827 100%)',
        borderTop: '2px solid rgba(0,212,170,0.2)',
      }}>
        <div style={{
          position: 'absolute', top: 0, left: 0, right: 0, height: 2,
          background: 'linear-gradient(90deg,transparent,var(--teal),transparent)',
        }} />
      </div>
      <div style={{
        position: 'absolute', bottom: 60, left: '50%', transform: 'translateX(-50%)',
        width: 560, height: 340,
        display: 'flex', alignItems: 'flex-end', justifyContent: 'center', gap: 40,
      }}>
        <Burette fillPercent={burettePercent} pouring={pouring} />
        <Beaker colorRgba={colorInfo.rgba} pouring={pouring} />
      </div>
      <TeacherVideo
        gestureActive={gestureActive}
        videoRef={videoRef}
        canvasRef={canvasRef}
        status={gestureStatus}
        errorMsg={errorMsg}
      />
      <div style={{
        position: 'absolute', inset: 0, pointerEvents: 'none',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        zIndex: 15, opacity: showEndpoint ? 1 : 0, transition: 'opacity 0.5s ease',
      }}>
        <div style={{
          background: 'rgba(0,212,170,0.12)', border: '1px solid var(--teal)',
          borderRadius: 16, padding: '20px 32px', textAlign: 'center', backdropFilter: 'blur(12px)',
        }}>
          <div style={{ fontFamily: 'Space Mono', fontSize: 22, color: 'var(--teal)', fontWeight: 700, marginBottom: 6, letterSpacing: 2 }}>
            ENDPOINT REACHED
          </div>
          <div style={{ fontSize: 14, color: 'var(--text-dim)' }}>
            Volume used: <strong style={{ color: '#e8eaf0' }}>{vol.toFixed(2)} mL</strong>
          </div>
        </div>
      </div>
    </main>
  )
}
