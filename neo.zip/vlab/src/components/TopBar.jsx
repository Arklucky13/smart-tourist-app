import React from 'react'

export function TopBar({ expName, gestureActive, onToggleGesture, onSave }) {
  return (
    <header
      style={{ background: 'var(--bg-card)', borderBottom: '1px solid var(--border)' }}
      className="flex items-center justify-between px-4 h-[52px] col-span-3"
    >
      <div className="font-mono text-sm tracking-[2px] font-bold" style={{ color: 'var(--teal)' }}>
        VLAB<span className="opacity-40 text-white"> | CHEM</span>
      </div>

      <div className="flex items-center gap-4">
        <div
          className="w-2 h-2 rounded-full animate-pulse-dot"
          style={{ background: 'var(--teal)', boxShadow: '0 0 6px var(--teal)' }}
        />
        <span className="text-sm font-medium text-white">{expName}</span>
        <span className="chip">LIVE SESSION</span>
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={onToggleGesture}
          className={`btn-base btn-gesture px-3 py-1.5 w-auto text-xs ${gestureActive ? 'active' : ''}`}
          title="Toggle MediaPipe hand gesture control"
        >
          {gestureActive ? '🤚 Gesture ON' : '✋ Enable Gesture'}
        </button>
        <button
          onClick={onSave}
          className="btn-base btn-save px-3 py-1.5 w-auto text-xs"
        >
          Save Session
        </button>
      </div>
    </header>
  )
}
