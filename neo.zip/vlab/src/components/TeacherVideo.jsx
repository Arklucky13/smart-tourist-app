import React from 'react'

const STATUS_LABEL = {
  idle: '',
  requesting: 'Requesting camera...',
  loading_model: 'Loading AI model...',
  active: 'GESTURE CAM',
  error: 'ERROR',
}

const STATUS_COLOR = {
  requesting: '#f59e0b',
  loading_model: '#a78bfa',
  active: '#00d4aa',
  error: '#f87171',
}

export function TeacherVideo({ gestureActive, videoRef, canvasRef, status, errorMsg }) {
  return (
    <div style={{
      position: 'absolute', top: 12, left: 12,
      width: 200, height: 130,
      borderRadius: 10, overflow: 'hidden',
      background: '#0d1117',
      border: `1px solid ${status === 'error' ? '#f87171' : 'var(--border-teal)'}`,
      boxShadow: '0 4px 24px rgba(0,0,0,0.5)',
      zIndex: 10,
    }}>
      {gestureActive ? (
        <div style={{ position: 'relative', width: '100%', height: '100%' }}>
          {/* Live webcam video */}
          <video
            ref={videoRef}
            style={{
              position: 'absolute', width: '100%', height: '100%',
              objectFit: 'cover', transform: 'scaleX(-1)',
              display: status === 'active' ? 'block' : 'none',
            }}
            autoPlay playsInline muted
          />

          {/* MediaPipe skeleton overlay */}
          <canvas
            ref={canvasRef}
            width={320} height={240}
            style={{
              position: 'absolute', top: 0, left: 0,
              width: '100%', height: '100%',
              transform: 'scaleX(-1)',
              display: status === 'active' ? 'block' : 'none',
            }}
          />

          {/* Loading / error state */}
          {status !== 'active' && (
            <div style={{
              width: '100%', height: '100%',
              display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center',
              gap: 8, padding: 12, textAlign: 'center',
              background: 'linear-gradient(135deg,#0d1117,#1a1f30)',
            }}>
              {status === 'error' ? (
                <>
                  <div style={{ fontSize: 20 }}>⚠️</div>
                  <div style={{ fontSize: 10, color: '#f87171', lineHeight: 1.4 }}>{errorMsg}</div>
                </>
              ) : (
                <>
                  <div style={{
                    width: 24, height: 24, border: '2px solid var(--teal)',
                    borderTopColor: 'transparent', borderRadius: '50%',
                    animation: 'spin 0.8s linear infinite',
                  }} />
                  <div style={{ fontSize: 10, color: 'var(--text-muted)' }}>
                    {STATUS_LABEL[status]}
                  </div>
                </>
              )}
            </div>
          )}

          {/* Status badge */}
          <div style={{
            position: 'absolute', top: 6, left: 8,
            fontSize: 9, color: '#fff',
            background: 'rgba(0,0,0,0.7)',
            padding: '2px 6px', borderRadius: 4,
            fontFamily: 'Space Mono',
          }}>
            {STATUS_LABEL[status] || 'GESTURE CAM'}
          </div>

          {/* Status dot */}
          <div style={{
            position: 'absolute', top: 8, right: 8,
            width: 7, height: 7, borderRadius: '50%',
            background: STATUS_COLOR[status] || '#6b7280',
            boxShadow: `0 0 6px ${STATUS_COLOR[status] || '#6b7280'}`,
            animation: status === 'active' ? 'pulse-dot 1.5s infinite' : 'none',
          }} />

          {/* Gesture hint when active */}
          {status === 'active' && (
            <div style={{
              position: 'absolute', bottom: 6, left: 0, right: 0,
              textAlign: 'center', fontSize: 9,
              color: 'rgba(255,255,255,0.5)',
              fontFamily: 'Space Mono',
            }}>
              ✊ pour  ·  ✋ stop
            </div>
          )}
        </div>
      ) : (
        /* Mock teacher avatar when gesture is off */
        <div style={{
          width: '100%', height: '100%',
          display: 'flex', flexDirection: 'column',
          alignItems: 'center', justifyContent: 'center',
          background: 'linear-gradient(135deg,#0d1117,#1a1f30)', gap: 6,
        }}>
          <div style={{
            width: 44, height: 44, borderRadius: '50%',
            background: 'linear-gradient(135deg, var(--teal), #3b82f6)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 18, color: '#fff', fontWeight: 600,
          }}>Dr</div>
          <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.4)', fontFamily: 'Space Mono' }}>
            Dr. Chen
          </div>
        </div>
      )}

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  )
}
