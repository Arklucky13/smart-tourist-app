import React from 'react'
import { formatTime } from '../lib/chemLogic'

function DataCard({ label, value, unit, percent, barColor }) {
  return (
    <div className="data-card">
      <div className="text-[10px] uppercase tracking-[1px] font-mono mb-1.5" style={{ color: 'var(--text-muted)' }}>
        {label}
      </div>
      <div className="text-2xl font-semibold font-mono" style={{ color: barColor || 'var(--teal)' }}>
        {value}
        {unit && <span className="text-xs ml-1" style={{ color: 'var(--text-muted)' }}>{unit}</span>}
      </div>
      {percent !== undefined && (
        <div className="mt-2 h-1.5 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)' }}>
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{ width: `${Math.min(100, Math.max(0, percent))}%`, background: barColor || 'var(--teal)' }}
          />
        </div>
      )}
    </div>
  )
}

export function SidebarRight({
  vol, buretteRemaining, burettePercent, fillPercent,
  colorInfo, suggestion, pouring, atEndpoint, gestureActive,
  onStartPour, onStopPour, onReset, onSave, replayProgress,
  sessions, onReplay, activeTab, onTabChange,
}) {
  return (
    <aside
      className="overflow-y-auto p-4 flex flex-col gap-3.5"
      style={{ background: 'var(--bg-panel)', borderLeft: '1px solid var(--border)' }}
    >
      {/* Tabs */}
      <div className="flex gap-1.5">
        {['data', 'history'].map(t => (
          <button
            key={t}
            onClick={() => onTabChange(t)}
            className="px-3 py-1 rounded-md text-xs font-medium transition-all duration-200 cursor-pointer"
            style={{
              border: '1px solid',
              borderColor: activeTab === t ? 'var(--border-teal)' : 'var(--border)',
              background: activeTab === t ? 'rgba(0,212,170,0.1)' : 'transparent',
              color: activeTab === t ? 'var(--teal)' : 'var(--text-muted)',
              fontFamily: 'DM Sans',
            }}
          >
            {t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      {activeTab === 'data' && (
        <>
          <DataCard
            label="Volume Added"
            value={vol.toFixed(2)}
            unit="mL"
            percent={fillPercent}
            barColor={vol >= 22.5 ? 'var(--teal)' : vol > 22.5 * 0.85 ? '#f59e0b' : '#60a5fa'}
          />
          <DataCard
            label="Burette Remaining"
            value={buretteRemaining.toFixed(2)}
            unit="mL left"
            percent={burettePercent}
            barColor="#60a5fa"
          />

          {/* Colour indicator */}
          <div className="data-card">
            <div className="text-[10px] uppercase tracking-[1px] font-mono mb-2" style={{ color: 'var(--text-muted)' }}>
              Solution Colour
            </div>
            <div className="flex items-center gap-3">
              <div
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: '50%',
                  background: colorInfo.rgba,
                  border: '1px solid rgba(255,255,255,0.1)',
                  transition: 'background 0.5s ease',
                  flexShrink: 0,
                }}
              />
              <span className="text-sm" style={{ color: 'var(--text-dim)' }}>{colorInfo.label}</span>
            </div>
          </div>

          {/* Smart suggestion */}
          <div className={`suggestion-${suggestion.type}`}>
            {suggestion.msg}
          </div>

          {/* Gesture hint */}
          {gestureActive && (
            <div
              className="rounded-xl p-3 text-xs text-center"
              style={{ background: 'rgba(167,139,250,0.08)', border: '1px solid rgba(167,139,250,0.25)', color: '#c4b5fd' }}
            >
              ✊ Make a fist to pour · ✋ Open palm to stop
            </div>
          )}

          {/* Controls */}
          <button
            className="btn-base btn-pour select-none"
            onMouseDown={onStartPour}
            onMouseUp={onStopPour}
            onMouseLeave={onStopPour}
            onTouchStart={e => { e.preventDefault(); onStartPour() }}
            onTouchEnd={onStopPour}
            disabled={atEndpoint || buretteRemaining <= 0}
          >
            {gestureActive ? '✊ Gesture or Hold to Pour' : 'Hold to Pour NaOH'}
          </button>

          <button className="btn-base btn-reset" onClick={onReset}>
            Reset Experiment
          </button>

          <button className="btn-base btn-save" onClick={onSave}>
            Save to History
          </button>

          {/* Replay progress bar */}
          {replayProgress > 0 && replayProgress < 100 && (
            <div
              className="rounded-lg p-2.5 flex items-center gap-3"
              style={{ background: 'rgba(0,0,0,0.4)', border: '1px solid var(--border-teal)' }}
            >
              <span className="text-xs font-mono" style={{ color: 'var(--teal)' }}>REPLAY</span>
              <div className="flex-1 h-1 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.1)' }}>
                <div
                  className="h-full rounded-full transition-all"
                  style={{ width: `${replayProgress}%`, background: 'var(--teal)' }}
                />
              </div>
            </div>
          )}
        </>
      )}

      {activeTab === 'history' && (
        <>
          {sessions.length === 0 ? (
            <div className="text-xs text-center py-8" style={{ color: 'var(--text-muted)' }}>
              No saved sessions yet.<br />Complete an experiment and save it.
            </div>
          ) : sessions.map(s => (
            <div
              key={s.id}
              onClick={() => onReplay(s)}
              className="rounded-xl p-3 cursor-pointer transition-all duration-200"
              style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid var(--border)' }}
              onMouseEnter={e => {
                e.currentTarget.style.borderColor = 'var(--border-teal)'
                e.currentTarget.style.background = 'var(--teal-glow)'
              }}
              onMouseLeave={e => {
                e.currentTarget.style.borderColor = 'var(--border)'
                e.currentTarget.style.background = 'rgba(255,255,255,0.02)'
              }}
            >
              <div className="text-[10px] font-mono" style={{ color: 'var(--text-muted)' }}>{formatTime(s.ts)}</div>
              <div
                className="text-xs mt-1"
                style={{ color: s.reached ? 'var(--teal)' : 'var(--text-dim)' }}
              >
                {s.reached ? '✓ Endpoint reached' : '○ Incomplete'} · {s.vol.toFixed(2)} mL
              </div>
              <div className="text-[10px] mt-1" style={{ color: 'var(--text-muted)' }}>Click to replay ▶</div>
            </div>
          ))}
        </>
      )}
    </aside>
  )
}
