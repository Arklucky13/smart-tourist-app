import React from 'react'

function SectionTitle({ children }) {
  return (
    <div className="flex items-center gap-2 mb-3">
      <span className="text-[10px] font-semibold tracking-[2px] uppercase" style={{ color: 'var(--text-muted)' }}>
        {children}
      </span>
      <div className="flex-1 h-px" style={{ background: 'var(--border)' }} />
    </div>
  )
}

function InfoBlock({ label, value }) {
  return (
    <div
      className="rounded-lg p-3 mb-2"
      style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid var(--border)' }}
    >
      <div className="text-[10px] mb-1 font-mono" style={{ color: 'var(--text-muted)' }}>{label}</div>
      <div className="text-[13px] leading-relaxed" style={{ color: '#e8eaf0' }}>{value}</div>
    </div>
  )
}

export function SidebarLeft({ experiment }) {
  return (
    <aside
      className="overflow-y-auto p-4"
      style={{ background: 'var(--bg-panel)', borderRight: '1px solid var(--border)' }}
    >
      <SectionTitle>Experiment</SectionTitle>
      <InfoBlock label="Purpose" value={experiment.purpose} />
      <InfoBlock label="Theory" value={experiment.theory} />
      <InfoBlock label="Indicator" value={experiment.indicator} />

      <SectionTitle>Required Tools</SectionTitle>
      <div className="flex flex-col gap-1.5">
        {experiment.tools.map(t => (
          <div
            key={t}
            className="flex items-center gap-2 px-2.5 py-2 rounded-md text-xs"
            style={{
              background: 'rgba(255,255,255,0.02)',
              border: '1px solid var(--border)',
              color: 'var(--text-dim)',
            }}
          >
            <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: 'var(--teal)' }} />
            {t}
          </div>
        ))}
      </div>
    </aside>
  )
}
