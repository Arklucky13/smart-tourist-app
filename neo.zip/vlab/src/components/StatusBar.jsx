import React from 'react'

export function StatusBar({ experiment, sessions, gestureActive, vol }) {
  const items = [
    { label: 'MODE', value: gestureActive ? 'GESTURE' : 'MOUSE' },
    { label: 'INDICATOR', value: experiment.indicator.toUpperCase() },
    { label: 'BURETTE', value: experiment.buretteSolution },
    { label: 'TARGET', value: `${experiment.endpoint} mL` },
    { label: 'VOL ADDED', value: `${vol.toFixed(2)} mL` },
    { label: 'SESSIONS', value: sessions },
  ]

  return (
    <footer
      className="col-span-3 flex items-center gap-6 px-4"
      style={{
        background: 'var(--bg-card)',
        borderTop: '1px solid var(--border)',
        height: 44,
        fontSize: 11,
        fontFamily: 'Space Mono',
        color: 'var(--text-muted)',
      }}
    >
      {items.map(({ label, value }) => (
        <div key={label} className="flex items-center gap-1.5">
          {label}{' '}
          <span style={{ color: 'var(--text-dim)' }}>{value}</span>
        </div>
      ))}
    </footer>
  )
}
