import React from 'react'

export function Burette({ fillPercent, pouring }) {
  // fillPercent = 0-100 representing NaOH remaining
  const liquidHeight = Math.max(0, Math.min(96, fillPercent))

  return (
    <div className="flex flex-col items-center" style={{ height: '320px', justifyContent: 'flex-start', paddingTop: 10 }}>
      {/* Stand */}
      <div className="relative flex flex-col items-center" style={{ height: '100%' }}>
        {/* Vertical rod */}
        <div
          style={{
            position: 'absolute',
            left: '50%',
            transform: 'translateX(-50%)',
            width: 3,
            height: '100%',
            background: 'linear-gradient(180deg,#374151,#1f2937)',
            borderRadius: 2,
          }}
        />
        {/* Clamp */}
        <div
          style={{
            position: 'absolute',
            top: 60,
            left: '50%',
            transform: 'translateX(-50%)',
            width: 44,
            height: 8,
            background: '#374151',
            borderRadius: 4,
            zIndex: 1,
          }}
        />

        {/* Burette glass tube */}
        <div
          style={{
            position: 'relative',
            zIndex: 2,
            marginTop: 32,
            width: 28,
            height: 200,
            background: 'rgba(200,230,255,0.07)',
            border: '1px solid rgba(200,230,255,0.22)',
            borderRadius: '4px 4px 2px 2px',
            overflow: 'hidden',
          }}
        >
          {/* NaOH liquid */}
          <div
            style={{
              position: 'absolute',
              bottom: 0,
              left: 0,
              right: 0,
              height: `${liquidHeight}%`,
              background: 'linear-gradient(180deg,rgba(147,197,253,0.45),rgba(147,197,253,0.2))',
              transition: 'height 0.4s cubic-bezier(0.4,0,0.2,1)',
            }}
          />
          {/* Graduation markings */}
          <div
            style={{
              position: 'absolute',
              right: -20,
              top: 0,
              height: '100%',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              padding: '4px 0',
              pointerEvents: 'none',
            }}
          >
            {['0','10','20','30','40','50'].map(m => (
              <span key={m} style={{ fontSize: 9, color: 'var(--text-muted)', fontFamily: 'Space Mono' }}>{m}</span>
            ))}
          </div>
        </div>

        {/* Tip */}
        <div
          style={{
            position: 'relative',
            zIndex: 2,
            width: 6,
            height: 30,
            background: 'rgba(200,230,255,0.12)',
            border: '1px solid rgba(200,230,255,0.18)',
            borderRadius: '0 0 3px 3px',
            marginTop: -1,
          }}
        >
          {/* Pour stream */}
          {pouring && (
            <div
              style={{
                position: 'absolute',
                top: '100%',
                left: '50%',
                transform: 'translateX(-50%)',
                width: 4,
                height: 130,
                background: 'linear-gradient(180deg,rgba(200,230,255,0.4),rgba(200,230,255,0.05))',
                borderRadius: 2,
                animation: 'pour-drip 0.3s ease forwards',
              }}
            />
          )}
        </div>

        {/* Label */}
        <div style={{ marginTop: 8, fontSize: 10, color: 'var(--text-muted)', fontFamily: 'Space Mono', textAlign: 'center' }}>
          NaOH 0.1M
        </div>
      </div>
    </div>
  )
}
