import { useState, useRef, useCallback, useEffect } from 'react'
import { getPourRate, getSolutionColor, getSuggestion, ACTIVE_EXPERIMENT } from '../lib/chemLogic'

const EXP = ACTIVE_EXPERIMENT

export function useTitration() {
  const [vol, setVol]             = useState(0)
  const [pouring, setPouring]     = useState(false)
  const [started, setStarted]     = useState(false)
  const [showEndpoint, setShowEndpoint] = useState(false)

  const pourIntervalRef = useRef(null)
  const eventLogRef     = useRef([])    // { t, v } for replay
  const volRef          = useRef(0)     // shadow ref for interval closure

  const colorInfo  = getSolutionColor(vol, EXP.endpoint)
  const suggestion = getSuggestion(vol, EXP.endpoint, started)
  const atEndpoint = vol >= EXP.endpoint
  const buretteRemaining = Math.max(0, EXP.buretteVolume - vol)
  const burettePercent   = (buretteRemaining / EXP.buretteVolume) * 100
  const fillPercent       = Math.min(100, (vol / EXP.buretteVolume) * 100)

  // Show endpoint overlay
  useEffect(() => {
    if (atEndpoint && !showEndpoint) {
      setShowEndpoint(true)
      const t = setTimeout(() => setShowEndpoint(false), 3000)
      return () => clearTimeout(t)
    }
  }, [atEndpoint])

  const startPour = useCallback(() => {
    if (volRef.current >= EXP.endpoint + 2 || buretteRemaining <= 0) return
    if (pourIntervalRef.current) return  // already running

    setPouring(true)
    setStarted(true)

    pourIntervalRef.current = setInterval(() => {
      const rate = getPourRate(volRef.current, EXP.endpoint)
      setVol(prev => {
        const next = parseFloat((prev + rate).toFixed(3))
        const clamped = Math.min(next, EXP.endpoint + 2)
        volRef.current = clamped
        eventLogRef.current.push({ t: Date.now(), v: clamped })
        if (clamped >= EXP.endpoint + 2) stopPour()
        return clamped
      })
    }, 80)
  }, [buretteRemaining])

  const stopPour = useCallback(() => {
    clearInterval(pourIntervalRef.current)
    pourIntervalRef.current = null
    setPouring(false)
  }, [])

  const reset = useCallback(() => {
    stopPour()
    setVol(0)
    volRef.current = 0
    setStarted(false)
    setShowEndpoint(false)
    eventLogRef.current = []
  }, [stopPour])

  const getSessionSnapshot = useCallback(() => ({
    id: Date.now(),
    ts: Date.now(),
    vol: parseFloat(vol.toFixed(2)),
    endpoint: EXP.endpoint,
    colorLabel: colorInfo.label,
    reached: atEndpoint,
    events: [...eventLogRef.current],
  }), [vol, colorInfo, atEndpoint])

  // Replay a saved session
  const replaySession = useCallback((session, onDone) => {
    reset()
    const events = session.events || []
    if (!events.length) return

    let i = 0
    const interval = setInterval(() => {
      if (i >= events.length) {
        clearInterval(interval)
        onDone?.()
        return
      }
      const e = events[i]
      setVol(e.v)
      volRef.current = e.v
      setStarted(true)
      i++
    }, 30)

    return () => clearInterval(interval)
  }, [reset])

  useEffect(() => () => clearInterval(pourIntervalRef.current), [])

  return {
    // state
    vol, pouring, started, showEndpoint, atEndpoint,
    colorInfo, suggestion, buretteRemaining, burettePercent, fillPercent,
    // actions
    startPour, stopPour, reset, getSessionSnapshot, replaySession,
    // experiment config
    experiment: EXP,
  }
}
