import { useEffect, useRef, useCallback, useState } from 'react'

function detectGesture(landmarks) {
  const tips = [8, 12, 16, 20]
  const pips = [6, 10, 14, 18]
  const foldedCount = tips.filter((tip, i) => landmarks[tip].y > landmarks[pips[i]].y).length
  if (foldedCount >= 3) return 'POUR'
  if (foldedCount <= 1) return 'STOP'
  return null
}

export function useHandGesture({ onGesture, enabled }) {
  const videoRef  = useRef(null)
  const canvasRef = useRef(null)
  const streamRef = useRef(null)
  const handsRef  = useRef(null)
  const rafRef    = useRef(null)
  const [status, setStatus] = useState('idle') // idle | requesting | active | error
  const [errorMsg, setErrorMsg] = useState('')

  const stopAll = useCallback(() => {
    cancelAnimationFrame(rafRef.current)
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop())
      streamRef.current = null
    }
    if (handsRef.current) {
      handsRef.current.close()
      handsRef.current = null
    }
    if (videoRef.current) videoRef.current.srcObject = null
    if (canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d')
      ctx.clearRect(0, 0, canvasRef.current.width, canvasRef.current.height)
    }
    setStatus('idle')
  }, [])

  const startAll = useCallback(async () => {
    setStatus('requesting')
    setErrorMsg('')

    // Step 1: get webcam stream directly (triggers browser permission popup)
    let stream
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 320, height: 240, facingMode: 'user' },
        audio: false,
      })
    } catch (err) {
      console.error('Camera access denied:', err)
      setStatus('error')
      if (err.name === 'NotAllowedError') {
        setErrorMsg('Camera permission denied. Click the camera icon in the address bar and allow access.')
      } else if (err.name === 'NotFoundError') {
        setErrorMsg('No camera found. Please connect a webcam and try again.')
      } else {
        setErrorMsg(`Camera error: ${err.message}`)
      }
      return
    }

    streamRef.current = stream

    // Step 2: attach stream to video element
    const video = videoRef.current
    if (!video) { stopAll(); return }
    video.srcObject = stream
    await new Promise(resolve => { video.onloadedmetadata = resolve })
    await video.play()

    setStatus('loading_model')

    // Step 3: load MediaPipe hands
    let Hands, drawConnectors, drawLandmarks, HAND_CONNECTIONS
    try {
      ;({ Hands, HAND_CONNECTIONS } = await import('@mediapipe/hands'))
      ;({ drawConnectors, drawLandmarks } = await import('@mediapipe/drawing_utils'))
    } catch (err) {
      console.error('MediaPipe load failed:', err)
      setStatus('error')
      setErrorMsg('Failed to load MediaPipe model. Check your internet connection and refresh.')
      stopAll()
      return
    }

    const hands = new Hands({
      locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands@0.4.1675469240/${file}`,
    })
    hands.setOptions({
      maxNumHands: 1,
      modelComplexity: 0,
      minDetectionConfidence: 0.65,
      minTrackingConfidence: 0.55,
    })
    hands.onResults((results) => {
      const canvas = canvasRef.current
      if (!canvas) return
      const ctx = canvas.getContext('2d')
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      if (results.multiHandLandmarks?.length) {
        const lm = results.multiHandLandmarks[0]
        drawConnectors(ctx, lm, HAND_CONNECTIONS, { color: '#00d4aa', lineWidth: 2 })
        drawLandmarks(ctx, lm, { color: '#f472b6', lineWidth: 1, radius: 3 })
        const g = detectGesture(lm)
        if (g) onGesture(g)
      } else {
        onGesture('STOP')
      }
    })
    handsRef.current = hands

    setStatus('active')

    // Step 4: run detection loop
    const detect = async () => {
      if (!videoRef.current || !handsRef.current) return
      try { await handsRef.current.send({ image: videoRef.current }) } catch {}
      rafRef.current = requestAnimationFrame(detect)
    }
    detect()
  }, [onGesture, stopAll])

  useEffect(() => {
    if (enabled) startAll()
    else stopAll()
    return stopAll
  }, [enabled])

  return { videoRef, canvasRef, status, errorMsg }
}
