/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        mono: ['"Space Mono"', 'monospace'],
        sans: ['"DM Sans"', 'sans-serif'],
      },
      colors: {
        teal: { DEFAULT: '#00d4aa', dim: '#009977' },
        lab: {
          deep: '#0a0e1a',
          card: '#111827',
          panel: '#161d2f',
        }
      }
    }
  },
  plugins: []
}
