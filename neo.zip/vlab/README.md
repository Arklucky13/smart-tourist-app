# Virtual Chemistry Lab 🧪

A React + Tailwind CSS virtual titration lab with **MediaPipe hand gesture control**.

## Quick Start

```bash
npm install
npm run dev
```

Open → http://localhost:5173

---

## Features

| Feature | Details |
|---|---|
| Titration simulation | Real-time colour change (colourless → pink) with smart endpoint detection |
| MediaPipe gesture control | ✊ Fist = pour · ✋ Open palm = stop |
| Smart suggestions | Adaptive advice based on proximity to endpoint |
| Session save & replay | Saves to localStorage, full frame-by-frame replay |
| Google Meet–style layout | Video panel, sidebar, main workspace |

## Gesture Control

1. Click **"✋ Enable Gesture"** in the top bar
2. Allow webcam access when prompted
3. Make a **fist (✊)** in front of the camera to pour NaOH
4. Open your **palm (✋)** to stop

MediaPipe Hand Landmarker runs entirely in-browser (no server needed).

## Folder Structure

```
src/
  components/         # UI components (TopBar, Burette, Beaker, ...)
  hooks/
    useTitration.js   # All titration state & logic
    useHandGesture.js # MediaPipe integration
  lib/
    chemLogic.js      # Colour, suggestion, pour-rate, session storage
  styles/
    index.css         # Tailwind + custom CSS variables
  App.jsx             # Root component
  main.jsx            # Entry point
```

## Adding New Experiments

Edit `src/lib/chemLogic.js` → add a new entry to `EXPERIMENTS` and change `ACTIVE_EXPERIMENT`.  
The UI components are fully data-driven from the experiment config object.

## Tech Stack

- **React 18** + **Vite**
- **Tailwind CSS v3**
- **@mediapipe/hands** — in-browser hand tracking
- **localStorage** — session persistence (swap for Firebase if needed)
